# proj

## 프로젝트 개요
- **연구 목표:** [여기에 테스트 목표 및 가설 작성]
- **연구 기간:** 2026-11-10 ~
- **담당 연구자:** [이름 작성]

## 하드웨어 및 소프트웨어 베이스라인 (Baseline)
- **HW Version:** [기구/회로/펌웨어의 기본 상태 명시]
- **SW Version:** [분석 스크립트 및 툴 환경 명시]

## 데이터 파이프라인 규격 (Protocol)
본 프로젝트는 Agile R&D Boilerplate 규격(ELF)을 준수함. (ELF 버전: `.elf/version` 참조)
- **rawData:** 센서 원시 데이터 보관 (읽기 전용)
- **metaData:** 세션-트라이얼 (Session-Trial) 기반 Base-Delta 마크다운 로깅
- **scripts:** 부분 실행 (Cell Mode)을 위한 후처리 스크립트 관리

## 프로젝트 규칙
해당 프로젝트만의 특수한 규칙 및 목표는 `0_Meta/ProjectRule.md`를 참조.
폴더 구조 및 운영 상세 규칙은 `.elf/managed/EliRule.md`를 참조.
AI 에이전트 로깅 규칙은 `.elf/managed/LogConvention.md`를 참조.
AI 컨텍스트 관리 규칙은 `.elf/managed/AI_PARA_Framework.md`를 참조.
data 파일(어휘·도메인) 커스터마이즈는 `0_Meta/<이름>.project.md` overlay를 사용 (EliRule §2.7).
규칙 정본 위치·소유권의 현행 기준은 `AGENTS.md`(digest) 참조.