## t{NN}: [작업 제목]

<!-- ### 배경 (Background) — 선택: 맥락이 목표를 초과할 때만(선행 종합, 다중 입력). 일반 trial은 생략.
- [trial 진입 의도, 맥락]
- **발의**: [사용자 제기 / AI 발상]
- [진입 시 기각한 경로 1줄 — 있을 때만] -->

### 목표 (Goal)
- [이 작업의 구체적 목표]

### 조건 (Conditions)
- [파라미터, 설정, 제약 조건]
- [반복 개선(delta) trial이면: base = 직전 trial, delta = 변경점 + 변경 이유(직전 시도 문제)]

### 가설 (Hypothesis)
- [Phase 1, 실행 전 작성 — 메커니즘, 효과 의심 3-5항, 명사형]
- [길어지면 → `../1_Concept/12_Planning/P00x.md#§N` cross-ref]

### 예상 (Prediction)
- [Phase 1, 실행 전 작성 — 결과 수치/방향/그래프 모양 1-3항]
- [정량 가능 시 정량, 정성도 허용]
- [figure 산출 trial: 예상 산출물(figure, 표) 목록 — 각 항목 = 생성 즉시 embed 대상]

### 관찰 (Observation)
- [Phase 2, 실행 후 작성 — 팩트 나열, Figure 인라인]
- [Figure는 생성 turn에 즉시 인라인 embed: `![<Fig 번호: 축, 핵심 관찰>](../6_Exp/64_Viz/S{NNN}/<file>.png)` — 표 경로 기재로 대체 금지]
- [가설/예상 대조 표 권장 (2열: `예상` vs `관찰`)]

### 해석 (Interpretation)
- 예상 일치 정도: [일치 / 부분 일치 / 불일치]
- [메커니즘, 물리적/논리적 해석]

### 교훈 (Lessons)
- [이 작업에서 얻은 핵심 인사이트]

### 생성 파일 (Files)

| 유형 | 파일 |
|------|------|
| Script | `경로` |
| Output | `경로` |
| Figure | `경로` |
