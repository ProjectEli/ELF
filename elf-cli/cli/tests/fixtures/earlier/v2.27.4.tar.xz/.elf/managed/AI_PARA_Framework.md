# AI PARA Framework & Context Management

이 문서는 프로젝트의 문서(세션 로그, 기획 문서)가 놓인 폴더로 그 문서의 상태를 나타내는 규칙과, AI 에이전트가 각 위치의 문서를 어떻게 읽고 써야 하는지를 정의함. 폐기, 구버전 기록이 현재의 사실로 잘못 쓰이는 것을 막고, 사람과 AI가 같은 기준으로 문서를 관리하기 위한 규칙임. 이름은 PARA(Projects, Areas, Resources, Archives) 체계에서 Archive 개념을 가져온 데서 왔으나, 본 규칙은 PARA를 몰라도 폴더 이름만으로 이해되도록 정의함.

## 1. 위치가 곧 상태 (Location = State)

파일명 접두, 태그, 별도 대장 없이, 문서가 놓인 폴더가 그 문서의 상태를 나타냄. 문서가 속한 폴더(예: `2_Log/`, `1_Concept/12_Planning/`) 아래에 같은 레벨의 상태 폴더 세 개를 둠.

| 위치 | 상태 | 내용 | AI 읽기 |
|------|------|------|--------|
| 폴더 루트 | 진행 중 | 지금 작성, 수정 중인 문서(예: `2_Log/S014_log.md`) | 현재 작업의 근거 |
| `Wiki/` | 핵심 요약 | 작업이 끝난 뒤 남는 확정 결론, 파라미터, 규칙을 한두 줄로 요약한 문서, Session Registry | 현재 사실의 요약 — 사람이 가장 먼저 보는 곳 |
| `Archive/` | 종료 보관 | 종료된 세션 로그, 계획 문서 원본(파일명 그대로 이동). 유효한 기록이며 과거 결론, 경로를 추적할 때 참조 | 읽기 허용 |
| `Deprecated/` | 폐기 | 과거에 시도했으나 폐기한 문서, 블록(`elf deprecate`로 이동). 대기 영역 — 영구 삭제는 사용자 결정으로 `elf deprecate purge`(experimental, 기본 비활성) | 읽기 허용 — 무엇을 시도했다가 폐기했는지 확인하는 용도. 현재 판단의 근거로 쓰지 않음 |

- 별도의 `1_Active` 폴더를 만들지 않음. 작업 중인 문서는 부모 폴더의 루트에 둠.
- 상태 폴더는 평탄함(하위 폴더 없음). 파일명은 이동해도 바뀌지 않음.
- 폐기 여부는 사용자가 결정함. 에이전트는 후보와 사유를 제시하고, 사용자의 지시나 승인이 있은 뒤 `elf deprecate`로 실행함. 형식, 절차는 `.elf/managed/LogConvention.md` §6.

### 1.1 정보용 companion (Informative Companion)

`*.en.md`(일반화 `*.<lang>.md`) 형식 파일은 거버넌스 문서의 **정보용 번역(read-only human companion)**임 — 국제 사용자의 *독해*용이며 operative source가 아님. operative 정본은 항상 동명 `*.md`(PROJECT_LANG 정본, 기본 한국어)임.

*   **AI 동작 규칙**: AI는 규칙, 구조, 지시를 **`*.md` 정본에서만** 취함. `*.en.md`는 동작 근거로 삼지 않음(읽더라도 규칙 source 아님). 정본과 companion이 충돌하면 **`*.md` 정본 우선**.
*   **커스터마이즈 방법**: 프로젝트 규칙 변경은 **`ProjectRule.md`(사용자 소유, operative, 프로젝트 언어)**에 작성함 — managed 정본이나 companion을 직접 편집하지 않음(managed는 `elf update`가 교체, companion 편집은 무효).
*   **효과**: operative 버전을 정본 하나로 고정하여 번역 차이가 AI 동작을 바꾸지 못하게 함. 국제 사용자도 ProjectRule로 자기 언어로 override 가능.

---

## 2. 세션 로그와 계획 문서의 이동

| 시점 | 동작 | 도구 |
|------|------|------|
| 세션 시작 | `2_Log/S###_log.md` 생성(루트 = 진행 중) | `elf session new` |
| 세션 종료 | 헤더 `Status: Complete`, 파일명 그대로 `2_Log/Archive/`로 이동, Registry 갱신, 로그 안 상대 링크 재계산 | `elf session close` |
| 폐기 | 문서 전체, trial, 절, 표시 블록, 줄 범위를 `Deprecated/`로 이동(원 위치에 이동 표기 1줄) | `elf deprecate` |
| 복원 | 폐기한 문서, 블록을 원 위치로 되돌림 | `elf deprecate --restore` |

- `Wiki/`의 요약 문서는 원본 로그(`Archive/...`)로 향하는 경로 링크를 포함함 — 과거 데이터가 필요할 때 그 링크로 원본을 읽음.
- 계획 문서(`1_Concept/12_Planning/`)도 같은 규칙: 루트 = 진행 중, `Wiki/` = 결론 요약, `Archive/` = 종료, `Deprecated/` = 폐기(파일 전체, 표시 블록, 줄 범위 — 계획 문서는 trial, 절 단위가 없음).

---

## 3. Scripts 폴더 관리

`61_Sim/Scripts`, `63_Analysis/Scripts` 안의 스크립트에도 같은 규칙을 적용함.

1.  **Active Scripts**: 현재 개발 중이거나 범용으로 쓰이는 최신 스크립트는 Scripts 폴더의 루트에 둠.
2.  **Archived Scripts**: 특정 과거 세션에만 일회용으로 쓰인 스크립트는 `Scripts/Archive/`로 이동함(삭제하지 않음 — 세션 재현에 필요).
3.  **Wiki Tracking**: 스크립트를 Archive로 옮길 때 어떤 세션에서 무엇을 위해 쓰였는지 `Wiki/` 문서에 **경로와 함께 표기**함.

## 4. 읽기 규칙 요약

| 문서 위치 | 현재 판단의 근거로 사용 | 비고 |
|----------|----------------------|------|
| 루트, `Wiki/` | 사용 | 현재 상태, 확정 결론 |
| `Archive/` | 사용(종료된 유효 기록) | 결론, 경로 추적, 과거 파라미터 확인 |
| `Deprecated/` | 사용하지 않음 | 과거에 시도했다가 폐기한 내용임을 알기 위해 읽음. 복원과 영구 삭제(purge)는 사용자 결정 |

- 사용자가 경로를 지정해 "이 파일을 열어 요약해 줘"라고 요청하면 위치와 무관하게 그 파일을 읽음.
- 폐기 내용을 다시 쓰려면 `elf deprecate --restore`로 복원한 뒤 사용함(폐기 상태의 블록을 복사해 쓰지 않음).
